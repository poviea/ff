package comment;

public class CommentDTO {

}
