package likeTbl;

public class LikeDTO {

}
