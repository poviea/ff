package board;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mysql.cj.Session;

import board.BoardDAO;
import board.BoardDTO;

// boardcon
@WebServlet("/ppProject.do")
public class BoardController extends HttpServlet {
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		String command = request.getParameter("command");
		
		if(command == null){
			command = "main";
		}		
		
		if(command.equals("main")){
			Main(request, response);
		}else if(command.equals("write")){
			write(request, response);
		}else if(command.equals("read")){
			read(request, response);
		}else if(command.equals("delete")){
			delete(request, response);
		}
	}

	private void write(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
		// write.html에서 입력된 값들을 가져온다.
		String title=request.getParameter("title");
		String content=request.getParameter("content");	
		String category=request.getParameter("category");
		
		//데이터값 입력 유무만 유효성 검증
		// database에서 해당 값들은 not null로 지저해주었기 때문에
		// 해당 값들이 null값이면 재입력할 수 있도록 write.html로 Redirect함
		if(title == null || title.trim().length() == 0 ||
		content == null || content.trim().length() == 0 ||
		category == null || category.trim().length() == 0 ){
			response.sendRedirect("write.html");
			return;//write() 메소드 종료
		}
		
		// 입력이 완료되었는지에 대한 결과를 의미
		boolean result = false;
		
		// BoardWrite.html의 form에서 넘어온 데이터들로 BoardDTO객체를 생성해
		// DAO에 넘겨준다!
		try {
			result = BoardDAO.writeContent(new BoardDTO(title, content, category));
		} catch (SQLException e) {
			e.printStackTrace();
			request.setAttribute("error", "게시글 저장 시도 실패 재 시도 하세요");
		}
		
		// DAO를 통해 반환되어온 result값이 true면, 글쓰기(insert)완료
				// Redirect를 통해 command값이 초기화(?)되어 list 목록을 불러오는 기능을 수행할 수 있도록 함!!
		if(result){
			response.sendRedirect("ppProject.do"); 
		}else{
			request.getRequestDispatcher("error.jsp").forward(request, response);
		}
	}
	
	private void Main(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String url = "error.jsp";
		try {
			// DAO에서 반환되어온 전체 데이터를 request 객체에 담아
			// Main.jsp에서 뿌려주는 것.
			request.setAttribute("Main", BoardDAO.getAllContents());
			url = "Main.jsp";
		} catch (SQLException e) {
			e.printStackTrace();
			request.setAttribute("error", "모두 보기 실패 재 실행 해 주세요");
		}	
		request.getRequestDispatcher(url).forward(request, response);
	}
	
	private void read(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
		String strNum=request.getParameter("board_cnum");
		if(strNum==null || strNum.length() == 0){
			response.sendRedirect("ppProject.do");
			return;
		}
		String url = "error.jsp";
		BoardDTO gContent = null;
		try {
			gContent = BoardDAO.getContent(Integer.parseInt(strNum), true);
			
		} catch (SQLException e) {
			e.printStackTrace();
			request.setAttribute("error", "게시글 읽기 실패");
		}
		
		if(gContent == null){
			request.setAttribute("error", "해당 게시글이 존재하지 않습니다");
		}else{
			request.setAttribute("resultContent", gContent);
			url = "BoardRead.jsp";
		}
		request.getRequestDispatcher(url).forward(request, response);
	}
	
	private void delete(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
		String strNum=request.getParameter("board_cnum");
		String empno = request.getParameter("empno");
		
		if(strNum == null || strNum.trim().length() == 0 ||
			empno == null || empno.trim().length() == 0){
			response.sendRedirect("ppProject.do");
			return;				
		}
		boolean result = false;
		try {
			result = BoardDAO.deleteContent(Integer.parseInt(strNum), Integer.parseInt(empno));
		} catch (SQLException e) {
			e.printStackTrace();
			request.setAttribute("error", "해당 게시글 삭제 실패했습니다. 재 시도 하셔요");
		}
		if(result){
			response.sendRedirect("ppProject.do");			
			return;
		}else{
			request.setAttribute("error", "삭제하려는 게시글이 존재하지 않습니다");
		}
		request.getRequestDispatcher("error.jsp").forward(request, response);
	}
	
	
	

}
