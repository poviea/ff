package hateTbl;

public class HateDTO {

}
