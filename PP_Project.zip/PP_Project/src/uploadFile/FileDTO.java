package uploadFile;

public class FileDTO {

}
